
import React from 'react';
import { LeafIcon } from './icons/LeafIcon'; // Changed from ShieldLockIcon
import { MagnifyingGlassIcon } from './icons/MagnifyingGlassIcon';
import { SimpleBrainIcon } from './icons/SimpleBrainIcon'; // Changed from BrainCircuitIcon


interface InfoCardProps {
  Icon: React.FC<React.SVGProps<SVGSVGElement>>;
  title: string;
  children: React.ReactNode;
  iconBgColor?: string;
  iconTextColor?: string;
}

const InfoCard: React.FC<InfoCardProps> = ({ Icon, title, children, iconBgColor = 'bg-brandLavender-light/60', iconTextColor = 'text-brandLavender-dark' }) => (
  <div className="bg-surface p-6 rounded-2xl shadow-subtle hover:shadow-card transition-shadow duration-300">
    <div className="flex items-start space-x-4">
      <div className={`p-3 rounded-lg ${iconBgColor} ${iconTextColor} inline-flex items-center justify-center`}>
        <Icon className="w-7 h-7" />
      </div>
      <div>
        <h3 className="text-xl font-semibold text-neutral-800 mb-2">{title}</h3>
        <div className="text-sm text-neutral-500 leading-relaxed space-y-2">
          {children}
        </div>
      </div>
    </div>
  </div>
);

const InformationalSection: React.FC = () => {
  return (
    <section id="learn" className="py-16 sm:py-24 bg-neutral-50">
      <div className="max-w-screen-lg mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 sm:mb-16">
          <h2 className="section-title">Understanding Cognitive Health & Early Insights</h2>
          <p className="section-subtitle">
            Knowledge is power. Learn about cognitive changes, the importance of early awareness, and proactive steps for brain wellness.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-1 gap-8">
          <InfoCard 
            Icon={SimpleBrainIcon} // Changed
            title="What are Alzheimer's & Dementia?"
            iconBgColor="bg-brandLavender-light/60"
            iconTextColor="text-brandLavender-dark"
          >
            <p>Dementia is an umbrella term for a range of progressive neurological disorders that affect brain function, impacting memory, thinking, language, and problem-solving abilities. Alzheimer's disease is the most common cause of dementia, accounting for a majority of cases.</p>
            <p>These conditions develop gradually, and early signs can be subtle. They are distinct from normal age-related memory lapses.</p>
          </InfoCard>

          <InfoCard 
            Icon={MagnifyingGlassIcon} 
            title="The Significance of Early Insights"
            iconBgColor="bg-brandLavender-light/60"
            iconTextColor="text-brandLavender-dark"
          >
            <p>Identifying potential cognitive changes at an early stage is crucial. While tools like Memory Guard do not diagnose conditions, they aim to raise awareness of patterns that warrant discussion with a healthcare professional.</p>
            <p>Early awareness can lead to:
              <ul className="list-disc list-inside mt-1 space-y-1 pl-2">
                <li>Timely medical consultation and comprehensive assessment.</li>
                <li>Access to support services and resources sooner.</li>
                <li>More opportunities to participate in clinical trials, if appropriate.</li>
                <li>Empowerment to make informed decisions about future care and lifestyle.</li>
              </ul>
            </p>
          </InfoCard>
          
          <InfoCard 
            Icon={LeafIcon} // Changed
            title="Proactive Steps & Brain Wellness" 
            iconBgColor="bg-green-100" // Adjusted for LeafIcon
            iconTextColor="text-green-700" // Adjusted for LeafIcon
          >
            <p>Current research suggests that certain lifestyle choices and proactive measures may support overall brain health and potentially reduce the risk or slow the progression of cognitive decline for some individuals. These include:</p>
            <ul className="list-disc list-inside mt-1 space-y-1 pl-2">
              <li>Regular physical exercise and maintaining cardiovascular health.</li>
              <li>A balanced, brain-healthy diet (e.g., rich in fruits, vegetables, lean proteins, healthy fats).</li>
              <li>Continuous mental stimulation through learning and engaging activities.</li>
              <li>Strong social connections and community involvement.</li>
              <li>Adequate sleep and effective stress management.</li>
            </ul>
            <p className="mt-2">Discussing cognitive concerns early with a doctor can help in formulating a personalized plan that may include these and other strategies.</p>
          </InfoCard>
        </div>
        <p className="mt-12 text-center text-xs text-neutral-400 max-w-3xl mx-auto leading-relaxed">
          The information provided in this section is for general educational purposes only and does not constitute medical advice. Memory Guard is not a diagnostic tool. Always consult with a qualified healthcare professional for diagnosis, treatment, and any questions regarding your personal health or medical conditions.
        </p>
      </div>
    </section>
  );
};

export default InformationalSection;
