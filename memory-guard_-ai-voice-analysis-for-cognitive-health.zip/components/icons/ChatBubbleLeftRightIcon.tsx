import React from 'react';

export const ChatBubbleLeftRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3.696-3.091c-.41-.343-.74-.034-1.152-.01H6.75A2.25 2.25 0 014.5 15V6.75A2.25 2.25 0 016.75 4.5h7.5c.884 0 1.673.483 2.064 1.215L16.5 8.25H20.25zM16.5 8.25V6h1.5v2.25h-1.5zM12 6.75V4.5A2.25 2.25 0 009.75 2.25H6.75A2.25 2.25 0 004.5 4.5v8.25A2.25 2.25 0 006.75 15h3.75a.75.75 0 01.75.75v1.619l1.642-1.369a.75.75 0 01.48-.18h2.028a2.25 2.25 0 002.25-2.25v-1.5a2.25 2.25 0 00-2.25-2.25H18a.75.75 0 01-.75-.75V6.75a.75.75 0 01.75-.75h.008c.414 0 .75.336.75.75v.008h.008a.75.75 0 00.75-.75V6a.75.75 0 00-.75-.75h-.008A2.25 2.25 0 0018 3H9.75A2.25 2.25 0 007.5 5.25v1.5h4.5z" />
  </svg>
);
// This icon is no longer directly used by core components after the refactor.
// It can be kept if there's a future need for this specific style.
