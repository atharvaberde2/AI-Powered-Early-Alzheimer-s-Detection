
import React from 'react';

// A clean document icon with three vertical bars.
export const DocumentChartBarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25V5.25c0-1.48-.937-2.731-2.25-3.149A8.905 8.905 0 0012 1.5c-1.897 0-3.64.716-4.991 1.915C5.625 4.586 4.5 6.265 4.5 8.25v10.5A2.25 2.25 0 006.75 21h10.5a2.25 2.25 0 002.25-2.25v-2.25" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 15.75V11.25M12 15.75V8.25m3 7.5V12.75" /> 
    </svg>
);
