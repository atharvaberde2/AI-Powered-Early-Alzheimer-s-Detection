import React from 'react';

export const MemoryGuardLogoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    {/* Lock Body */}
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 00-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
    {/* Sound Bars inside the lock */}
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 14.25v-1.5M10.5 15v-3M13.5 15v-3" />
    {/* Keyhole (optional, can make it look more like a lock, but might be too much detail) */}
    {/* <path strokeLinecap="round" strokeLinejoin="round" d="M12 15.75a.75.75 0 100-1.5.75.75 0 000 1.5z" /> */}
  </svg>
);
