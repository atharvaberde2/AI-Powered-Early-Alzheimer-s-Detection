
import React from 'react';

// Simple sprout icon, named LeafIcon for consistency with usage
export const LeafIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.375a9.375 9.375 0 01-6.625-2.75L12 8.25l6.625 7.375A9.375 9.375 0 0112 18.375z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 2.25v6" />
    </svg>
);
