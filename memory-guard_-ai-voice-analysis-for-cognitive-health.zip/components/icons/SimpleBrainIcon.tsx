import React from 'react';

export const SimpleBrainIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 6.026A5.001 5.001 0 0012 5.25c1.886 0 3.53.958 4.5 2.438M12 5.25V3M9.75 6.026V3.75m4.5 2.276V3.75M3.75 10.875c0-2.395 1.083-4.57 2.766-6.044M20.25 10.875c0-2.395-1.083-4.57-2.766-6.044M12 21a8.25 8.25 0 006.563-3.437M12 21a8.25 8.25 0 01-6.563-3.437M12 21V10.875m0 10.125c-1.35 0-2.67-.174-3.938-.51M12 21c1.35 0 2.67-.174 3.938-.51M9 13.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm6 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm-3-2.25a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 4.5a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
  </svg>
);
