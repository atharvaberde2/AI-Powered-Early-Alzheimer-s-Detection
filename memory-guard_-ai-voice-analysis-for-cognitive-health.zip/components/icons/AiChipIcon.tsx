import React from 'react';

export const AiChipIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    {/* Simplified chip outline */}
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 6h-15A2.5 2.5 0 002 8.5v7A2.5 2.5 0 004.5 18h15a2.5 2.5 0 002.5-2.5v-7A2.5 2.5 0 0019.5 6z" />
    {/* Simplified internal square representing the die */}
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.5 10.5h-7v3h7v-3z" />
    {/* Simplified legs/pins */}
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.5 6V4.5M10.5 6V4.5M13.5 6V4.5M17.5 6V4.5M6.5 18v1.5M10.5 18v1.5M13.5 18v1.5M17.5 18v1.5M2 10.5H3.5M2 13.5H3.5M20.5 10.5H22M20.5 13.5H22" />
  </svg>
);
