
import React from 'react';

// Simplified 6-tooth cog icon
export const CogIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.34 2.257a10.473 10.473 0 006.32 0M6.75 21.75a10.473 10.473 0 016.502-9.207M3.929 15.855A10.473 10.473 0 012.25 10.34M10.34 2.257L12 4.5m0 15l-1.66-2.243M3.929 15.855L5.25 12m14.821 3.855L18.75 12M13.66 2.257L12 4.5m6.502 15L12 19.5M21.75 10.34L19.5 12M12 15.75a3.75 3.75 0 100-7.5 3.75 3.75 0 000 7.5z" />
  </svg>
);
