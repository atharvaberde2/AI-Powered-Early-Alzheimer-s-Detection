
import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <section id="home" className="bg-gradient-to-br from-brandLavender-light via-brandLavender-DEFAULT to-brandLavender-medium py-24 md:py-36">
      <div className="max-w-screen-lg mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight tracking-tight">
          <span className="block">Early Insights for</span>
          <span className="block text-brandLavender-xlight mt-1 sm:mt-2">Proactive Cognitive Health</span>
        </h1>
        <p className="mt-6 max-w-2xl mx-auto text-lg md:text-xl text-brandLavender-xlight/90 font-light leading-relaxed">
          Memory Guard utilizes advanced AI and voice analysis to detect subtle patterns that may indicate early cognitive changes. Empower yourself with knowledge and take proactive steps towards brain wellness.
        </p>
        <div className="mt-10 sm:mt-12">
          <a
            href="#features"
            className="inline-block bg-surface text-brandLavender-dark font-semibold px-8 py-3.5 rounded-xl shadow-card hover:bg-opacity-90 transform hover:scale-105 transition-all duration-300 text-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brandLavender-DEFAULT focus:ring-white"
          >
            Discover How It Works
          </a>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;