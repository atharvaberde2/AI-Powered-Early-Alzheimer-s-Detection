
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-800 text-neutral-300">
      <div className="max-w-screen-xl mx-auto py-10 px-4 sm:px-6 lg:px-8 text-center">
        <p className="text-sm">
          &copy; {new Date().getFullYear()} Memory Guard. All rights reserved.
        </p>
        <p className="text-xs text-neutral-400 mt-3 max-w-3xl mx-auto leading-relaxed">
          Memory Guard is an informational tool designed to provide insights based on voice patterns. It does not offer medical advice, diagnosis, or treatment. All information and results should be discussed with a qualified healthcare professional. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.
        </p>
        <div className="mt-5 space-x-5">
            <a href="#privacy" className="text-xs text-neutral-300 hover:text-brandLavender-light transition-colors duration-200">Privacy Policy</a>
            <span className="text-neutral-500">|</span>
            <a href="#terms" className="text-xs text-neutral-300 hover:text-brandLavender-light transition-colors duration-200">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;