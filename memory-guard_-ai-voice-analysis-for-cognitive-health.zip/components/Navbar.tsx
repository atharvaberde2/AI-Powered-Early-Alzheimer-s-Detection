import React, { useState } from 'react';
import { MemoryGuardLogoIcon } from './icons/MemoryGuardLogoIcon'; // Changed Icon

const Navbar: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: '#home', text: 'Home' },
    { href: '#features', text: 'Features' },
    { href: '#howitworks', text: 'How It Works' },
    { href: '#learn', text: 'Learn' },
    { href: '#voice-analysis', text: 'Voice Analysis' },
    { href: '#ai-assistant', text: 'AI Assistant' },
    { href: '#cta', text: 'Get Started' },
  ];

  return (
    <nav className="bg-surface/80 backdrop-blur-md shadow-subtle sticky top-0 z-50">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <MemoryGuardLogoIcon className="h-9 w-9 text-brandLavender-medium" /> {/* Changed Icon */}
            <span className="ml-2.5 text-3xl font-bold text-brandLavender-dark">Memory Guard</span>
          </div>
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map(link => (
              <a 
                key={link.text}
                href={link.href} 
                className="text-neutral-600 hover:text-brandLavender-dark hover:bg-brandLavender-light/50 px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200"
              >
                {link.text}
              </a>
            ))}
          </div>
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-neutral-500 hover:text-brandLavender-medium hover:bg-brandLavender-light/50 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brandLavender-DEFAULT"
              aria-controls="mobile-menu"
              aria-expanded={isMobileMenuOpen}
            >
              <span className="sr-only">Open main menu</span>
              {isMobileMenuOpen ? (
                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu, show/hide based on menu state. */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-20 inset-x-0 z-40 bg-surface/95 backdrop-blur-md shadow-lg" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map(link => (
              <a
                key={link.text}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-neutral-700 hover:text-brandLavender-dark hover:bg-brandLavender-light/50 block px-3 py-2 rounded-md text-base font-medium transition-colors duration-200"
              >
                {link.text}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;