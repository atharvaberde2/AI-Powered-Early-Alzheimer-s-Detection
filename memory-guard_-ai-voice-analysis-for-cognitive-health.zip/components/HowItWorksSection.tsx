
import React from 'react';
import { SimpleChatBubbleIcon } from './icons/SimpleChatBubbleIcon'; // Changed
import { CogIcon } from './icons/CogIcon'; // Will be simplified version
import { DocumentChartBarIcon } from './icons/DocumentChartBarIcon'; // Will be simplified version

interface Step {
  id: number;
  Icon: React.FC<React.SVGProps<SVGSVGElement>>;
  title: string;
  description: string;
}

const steps: Step[] = [
  {
    id: 1,
    Icon: SimpleChatBubbleIcon, // Changed
    title: 'Speak Naturally',
    description: 'Record a short voice sample by responding to simple prompts or uploading a recording. The process is quick and intuitive.',
  },
  {
    id: 2,
    Icon: CogIcon, // Simplified
    title: 'AI-Powered Analysis',
    description: 'Our advanced AI processes your voice, analyzing numerous acoustic and linguistic features for subtle patterns.',
  },
  {
    id: 3,
    Icon: DocumentChartBarIcon, // Simplified
    title: 'Understandable Insights',
    description: 'Receive a summary of findings in an easy-to-understand format. This is not a diagnosis but a tool for awareness.',
  },
];

const HowItWorksSection: React.FC = () => {
  return (
    <section id="howitworks" className="py-16 sm:py-24 bg-neutral-50">
      <div className="max-w-screen-lg mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 sm:mb-20">
          <h2 className="section-title">Simple Steps to Valuable Insights</h2>
          <p className="section-subtitle">
            Our process is designed for ease of use, providing information to foster awareness of cognitive patterns.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 items-start">
          {steps.map((step, index) => (
            <div key={step.id} className="flex flex-col items-center text-center p-4">
              <div className="relative flex items-center justify-center mb-6">
                {/* Dashed line for larger screens */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 left-full w-full">
                    <svg viewBox="0 0 100 1" preserveAspectRatio="none" className="h-10 text-neutral-300/70" style={{ transform: 'translateY(-50%)', marginLeft: '1rem', marginRight: '1rem' }}>
                      <line x1="0" y1="0.5" x2="100" y2="0.5" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" /> {/* Thinner, lighter, adjusted dash */}
                    </svg>
                  </div>
                )}
                {/* Vertical dashed line for smaller screens */}
                 {index < steps.length - 1 && (
                  <div className="md:hidden absolute top-full left-1/2 h-10 w-px -translate-x-1/2 mt-2 mb-2">
                     <svg height="100%" width="100%" >
                       <line x1="50%" y1="0" x2="50%" y2="100%" stroke="currentColor" className="text-neutral-300/70" strokeWidth="1" strokeDasharray="3 3"/> {/* Thinner, lighter, adjusted dash */}
                     </svg>
                  </div>
                )}
                <div className="bg-brandLavender-medium text-white p-5 rounded-full shadow-md z-10">
                  <step.Icon className="w-10 h-10" />
                </div>
              </div>
              <h3 className="mt-2 text-xl font-semibold text-neutral-800">{step.title}</h3>
              <p className="mt-2 text-neutral-500 text-sm leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>
         <p className="mt-16 text-center text-xs text-neutral-400 max-w-3xl mx-auto leading-relaxed">
            <strong>Important Disclaimer:</strong> Memory Guard provides insights based on voice patterns and is an informational tool, not a diagnostic one. Any information or results should be discussed with a qualified healthcare professional. It does not replace professional medical advice, diagnosis, or treatment.
          </p>
      </div>
    </section>
  );
};

export default HowItWorksSection;
