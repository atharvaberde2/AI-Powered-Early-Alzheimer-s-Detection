
import React, { useState, useCallback, useRef } from 'react';
import { analyzeAudioForCognitivePatterns } from '../services/geminiService';
import { UploadIcon } from './icons/UploadIcon';
import { AudioFileIcon } from './icons/AudioFileIcon';
import { SimpleBrainIcon } from './icons/SimpleBrainIcon'; // Changed from BrainCircuitIcon

const VoiceAnalysisSection: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [audioBase64, setAudioBase64] = useState<string | null>(null);
  const [audioMimeType, setAudioMimeType] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const MAX_FILE_SIZE_MB = 10;
  const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
  const SUPPORTED_AUDIO_TYPES = ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/ogg', 'audio/aac', 'audio/flac', 'audio/x-m4a', 'audio/m4a'];


  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > MAX_FILE_SIZE_BYTES) {
        setError(`File is too large. Maximum size is ${MAX_FILE_SIZE_MB}MB.`);
        setSelectedFile(null);
        setAudioBase64(null);
        setAudioMimeType(null);
        return;
      }
      if (!SUPPORTED_AUDIO_TYPES.includes(file.type)) {
        setError(`Unsupported file type. Please upload a common audio format (e.g., MP3, WAV, M4A). Detected: ${file.type}`);
        setSelectedFile(null);
        setAudioBase64(null);
        setAudioMimeType(null);
        return;
      }

      setSelectedFile(file);
      setError(null);
      setAnalysisResult(null); // Clear previous results

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setAudioBase64(base64String);
        setAudioMimeType(file.type);
      };
      reader.onerror = () => {
        setError('Failed to read the audio file. Please try again.');
        setSelectedFile(null);
        setAudioBase64(null);
        setAudioMimeType(null);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const handleAnalyzeClick = useCallback(async () => {
    if (!audioBase64 || !audioMimeType || !selectedFile) {
      setError('Please select an audio file first.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const result = await analyzeAudioForCognitivePatterns(audioBase64, audioMimeType);
      setAnalysisResult(result);
    } catch (err: any) { 
      setError((err as Error).message || 'An unknown error occurred during analysis.');
      console.error("Voice Analysis Error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [audioBase64, audioMimeType, selectedFile]);

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <section id="voice-analysis" className="py-16 sm:py-24 bg-neutral-100">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-14">
          <SimpleBrainIcon className="w-12 h-12 text-brandLavender-medium mx-auto mb-4" /> {/* Changed Icon */}
          <h2 className="section-title">Voice Pattern Analysis</h2>
          <p className="section-subtitle !max-w-2xl">
            Upload a short voice recording to explore general speech patterns. This tool provides informational insights, not medical diagnoses.
          </p>
        </div>

        <div className="bg-surface p-6 sm:p-8 rounded-2xl shadow-card">
          <div className="mb-6 p-4 bg-brandLavender-xlight border border-brandLavender-light rounded-lg text-sm text-brandLavender-dark">
            <h4 className="font-semibold mb-1">Important Considerations:</h4>
            <ul className="list-disc list-inside space-y-1 text-neutral-600 text-xs sm:text-sm">
              <li><strong>Not a Diagnostic Tool:</strong> This analysis is for informational purposes only and does not substitute professional medical advice, diagnosis, or treatment.</li>
              <li><strong>General Patterns:</strong> The AI identifies general speech characteristics. It cannot determine cognitive health status.</li>
              <li><strong>Privacy:</strong> Your audio is processed for analysis and not stored long-term by Memory Guard beyond this session. Refer to our privacy policy for details about API usage.</li>
              <li><strong>Consult Professionals:</strong> Always discuss any health concerns, including cognitive health, with a qualified healthcare provider.</li>
            </ul>
          </div>

          <div className="space-y-5">
            <input
              type="file"
              accept="audio/*"
              onChange={handleFileChange}
              ref={fileInputRef}
              className="hidden"
              aria-label="Upload audio file"
            />
            
            {!selectedFile && (
              <button
                type="button"
                onClick={triggerFileInput}
                className="w-full flex items-center justify-center px-6 py-4 border-2 border-dashed border-brandLavender-DEFAULT text-brandLavender-dark hover:border-brandLavender-medium hover:bg-brandLavender-xlight rounded-xl transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-brandLavender-medium focus:ring-offset-2"
                aria-describedby="file-upload-description"
              >
                <UploadIcon className="w-6 h-6 mr-3" />
                <span>Click to Upload Audio File</span>
              </button>
            )}
             <p id="file-upload-description" className="text-xs text-neutral-500 text-center">
                (Max file size: {MAX_FILE_SIZE_MB}MB. Supported: MP3, WAV, M4A, OGG, etc.)
             </p>


            {selectedFile && (
              <div className="p-4 bg-neutral-100 rounded-lg flex items-center justify-between space-x-3">
                <div className="flex items-center space-x-3 min-w-0">
                  <AudioFileIcon className="w-7 h-7 text-brandLavender-medium flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-neutral-700 truncate" title={selectedFile.name}>{selectedFile.name}</p>
                    <p className="text-xs text-neutral-500">{(selectedFile.size / (1024 * 1024)).toFixed(2)} MB</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFile(null);
                    setAudioBase64(null);
                    setAudioMimeType(null);
                    setAnalysisResult(null);
                    setError(null);
                    if (fileInputRef.current) fileInputRef.current.value = ""; // Reset file input
                  }}
                  className="text-sm text-red-500 hover:text-red-700 font-medium focus:outline-none"
                  aria-label="Remove selected file"
                >
                  Remove
                </button>
              </div>
            )}

            {selectedFile && audioBase64 && (
              <button
                type="button"
                onClick={handleAnalyzeClick}
                disabled={isLoading}
                className="w-full flex items-center justify-center px-6 py-3.5 bg-brandLavender-dark hover:bg-opacity-90 text-white font-semibold rounded-xl shadow-md focus:outline-none focus:ring-2 focus:ring-brandLavender-medium focus:ring-offset-2 disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-200"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Analyzing...
                  </>
                ) : (
                  'Analyze Voice Sample'
                )}
              </button>
            )}
          </div>

          {error && (
            <div className="mt-6 p-4 bg-red-50 text-red-700 rounded-xl shadow-sm">
              <p className="text-sm">{error}</p>
            </div>
          )}

          {isLoading && !analysisResult && !error && (
            <div className="mt-6 text-center">
                <p className="text-sm text-neutral-500">Processing audio and analyzing patterns. This may take a moment...</p>
            </div>
          )}

          {analysisResult && (
            <div className="mt-8 pt-6 border-t border-neutral-200">
              <h3 className="text-lg font-semibold text-neutral-800 mb-3">Analysis Results:</h3>
              <div className="p-4 sm:p-5 bg-brandLavender-xlight rounded-xl shadow-sm text-neutral-700 text-sm whitespace-pre-wrap leading-relaxed">
                {analysisResult}
              </div>
               <p className="mt-4 text-xs text-neutral-500">
                <strong>Disclaimer:</strong> This analysis is based on general speech patterns observed in the audio sample and is for informational purposes only. It is not a medical diagnosis or assessment. For any health concerns or questions about cognitive health, please consult a qualified healthcare professional.
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default VoiceAnalysisSection;
