
import React, { useState, useCallback } from 'react';
import { getInformativeAnswer } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';
import { PaperAirplaneIcon } from './icons/PaperAirplaneIcon';

const AiAssistantSection: React.FC = () => {
  const [query, setQuery] = useState<string>('');
  const [response, setResponse] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) {
      setError('Please enter a question to ask the AI assistant.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResponse('');

    try {
      const answer = await getInformativeAnswer(query);
      setResponse(answer);
    } catch (err: any) {
      setError(err.message || 'Failed to get a response from the AI assistant. Please check your connection or try again later.');
      console.error("AI Assistant Error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [query]);

  return (
    <section id="ai-assistant" className="py-16 sm:py-24 bg-surface">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-14">
          <SparklesIcon className="w-12 h-12 text-brandLavender-medium mx-auto mb-4" />
          <h2 className="section-title">Ask Our AI Assistant</h2>
          <p className="section-subtitle !max-w-xl">
            Get general information about cognitive health, dementia, Alzheimer's, and the role of AI.
          </p>
           <p className="mt-3 text-xs text-neutral-400">
            (Powered by Google Gemini. This tool provides general information and is not a substitute for professional medical advice.)
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="ai-query" className="sr-only">
              Your question for the AI assistant
            </label>
            <div className="flex rounded-xl shadow-subtle focus-within:ring-2 focus-within:ring-brandLavender-DEFAULT focus-within:ring-offset-2 focus-within:ring-offset-surface transition-shadow duration-200">
                <input
                type="text"
                name="ai-query"
                id="ai-query"
                value={query}
                onChange={(e) => {
                    setQuery(e.target.value);
                    if (error) setError(null); // Clear error on new input
                }}
                className="flex-1 block w-full rounded-l-xl sm:text-sm border-neutral-300 p-3.5 bg-surface placeholder-neutral-400 text-neutral-700 focus:border-transparent focus:ring-0"
                placeholder="E.g., How can lifestyle affect cognitive health?"
                />
                <button
                type="submit"
                disabled={isLoading}
                className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-sm font-medium rounded-r-xl text-white bg-brandLavender-medium hover:bg-brandLavender-dark focus:outline-none focus:ring-2 focus:ring-brandLavender-DEFAULT focus:ring-offset-2 focus:ring-offset-surface disabled:opacity-60 disabled:cursor-not-allowed transition-colors duration-200"
                >
                {isLoading ? (
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                ) : (
                   <PaperAirplaneIcon className="h-5 w-5 transform rotate-90" />
                )}
                <span className="ml-2 hidden sm:inline">{isLoading ? 'Asking...' : 'Ask AI'}</span>
                </button>
            </div>
          </div>
        </form>

        {error && (
          <div className="mt-5 p-4 bg-red-50 text-red-700 rounded-xl shadow-sm">
            <p className="text-sm">{error}</p>
          </div>
        )}

        {isLoading && !response && !error && (
            <div className="mt-6 text-center">
                <p className="text-sm text-neutral-500">Thinking...</p>
            </div>
        )}

        {response && (
          <div className="mt-6 p-5 bg-brandLavender-xlight rounded-xl shadow-sm">
            <h4 className="text-sm font-semibold text-brandLavender-dark mb-2">AI Assistant's Response:</h4>
            <p className="text-neutral-700 text-sm whitespace-pre-wrap leading-relaxed">{response}</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default AiAssistantSection;