
import React from 'react';
import { MicrophoneIcon } from './icons/MicrophoneIcon';
import { AiChipIcon } from './icons/AiChipIcon'; // Will be simplified version
import { MagnifyingGlassIcon } from './icons/MagnifyingGlassIcon';
import { ShieldIcon } from './icons/ShieldIcon'; // Changed from ShieldLockIcon
import { Feature } from '../types';

const features: Feature[] = [
  {
    Icon: MicrophoneIcon,
    title: 'Voice-Powered Analysis',
    description: 'Sophisticated voice recognition captures linguistic and acoustic features from your speech patterns.',
    bgColor: 'bg-brandLavender-light/50', 
    iconColor: 'text-brandLavender-dark',
  },
  {
    Icon: AiChipIcon, // Using simplified AiChipIcon
    title: 'AI-Driven Insights',
    description: 'Our AI algorithms analyze speech, identifying subtle markers potentially linked to cognitive changes.',
    bgColor: 'bg-neutral-100', 
    iconColor: 'text-brandLavender-medium',
  },
  {
    Icon: MagnifyingGlassIcon,
    title: 'Focus on Early Indicators',
    description: 'Designed to help identify early signs, enabling timely consultation and proactive cognitive care.',
    bgColor: 'bg-brandLavender-light/50',
    iconColor: 'text-brandLavender-dark',
  },
  {
    Icon: ShieldIcon, // Changed to simple ShieldIcon
    title: 'Secure & Private',
    description: 'Your privacy is paramount. Data is handled securely, confidentially, and ethically.',
    bgColor: 'bg-neutral-100',
    iconColor: 'text-brandLavender-medium',
  },
];

const FeatureCard: React.FC<{ feature: Feature }> = ({ feature }) => {
  const { Icon, title, description, bgColor, iconColor } = feature;
  return (
    <div className={`p-6 md:p-8 rounded-2xl shadow-subtle flex flex-col items-center text-center ${bgColor} transition-all duration-300 hover:shadow-card`}>
      <div className={`p-4 rounded-full ${iconColor} bg-surface mb-5 inline-block shadow-sm`}>
        <Icon className="w-10 h-10" />
      </div>
      <h3 className="text-xl font-semibold text-neutral-800 mb-2">{title}</h3>
      <p className="text-neutral-500 text-sm leading-relaxed">{description}</p>
    </div>
  );
};

const FeaturesSection: React.FC = () => {
  return (
    <section id="features" className="py-16 sm:py-24 bg-surface">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 sm:mb-16">
          <h2 className="section-title">Empowering Your Cognitive Journey</h2>
          <p className="section-subtitle">
            Discover innovative features that make Memory Guard a unique tool for understanding cognitive patterns.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {features.map((feature) => (
            <FeatureCard key={feature.title} feature={feature} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
