
import React from 'react';

const CallToActionSection: React.FC = () => {
  return (
    <section id="cta" className="bg-gradient-to-r from-brandLavender-medium to-brandLavender-dark py-20 sm:py-28">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
          Ready to Learn More About Your Cognitive Wellness?
        </h2>
        <p className="mt-5 text-lg text-brandLavender-xlight/90 max-w-2xl mx-auto leading-relaxed font-light">
          Memory Guard is currently under development. Sign up for our mailing list to receive updates on our progress, insights into cognitive health research, and notification of our launch.
        </p>
        <div className="mt-10 sm:mt-12 flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <a
            href="mailto:updates@memoryguard.example.com?subject=Interest%20in%20Memory%20Guard%20Updates"
            className="inline-block bg-surface text-brandLavender-dark font-semibold px-8 py-3.5 rounded-xl shadow-card hover:bg-opacity-90 transform hover:scale-105 transition-all duration-300 text-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brandLavender-medium focus:ring-white w-full sm:w-auto"
          >
            Request Updates
          </a>
          <a
            href="#learn"
            className="inline-block bg-transparent border-2 border-brandLavender-xlight/80 text-white font-semibold px-8 py-3.5 rounded-xl hover:bg-white hover:text-brandLavender-dark transition-all duration-300 text-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brandLavender-medium focus:ring-white w-full sm:w-auto"
          >
            Learn More
          </a>
        </div>
      </div>
    </section>
  );
};

export default CallToActionSection;