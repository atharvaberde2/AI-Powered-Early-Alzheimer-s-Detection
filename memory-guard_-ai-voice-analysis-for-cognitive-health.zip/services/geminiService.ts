
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_MODEL_NAME } from '../constants';

// Ensure process.env.API_KEY is handled by the build/runtime environment
const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.warn("API_KEY environment variable not set. Gemini API calls will fail for Memory Guard assistant and voice analysis.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "MISSING_API_KEY" }); // Fallback to prevent crash if key is missing

const SYSTEM_INSTRUCTION_CHATBOT = `You are a helpful and empathetic AI assistant for Memory Guard, specializing in providing general information about cognitive health, Alzheimer's disease, dementia, preventative measures, and the importance of early detection.
Your responses should be:
1. Informative, clear, and easy to understand for a general audience.
2. Empathetic, supportive, and hopeful in tone, focusing on proactive steps and awareness.
3. Strictly general information. You MUST NOT provide medical advice, diagnosis, treatment recommendations, or interpret individual results.
4. When discussing early detection or preventative measures, emphasize that these are general concepts and individual situations require professional medical consultation.
5. Always conclude by strongly advising the user to consult with a qualified healthcare professional for any personal health concerns, medical advice, or before making any decisions related to their health.
6. Keep answers concise and well-structured, ideally under 150-200 words.
7. If asked about "Memory Guard" itself, explain it's a tool for providing insights into voice patterns that may be relevant to cognitive health awareness and is not a diagnostic tool.`;

export const getInformativeAnswer = async (query: string): Promise<string> => {
  if (!apiKey || apiKey === "MISSING_API_KEY") {
    console.error("Memory Guard AI Assistant: API key is not configured.");
    throw new Error("The AI assistant is currently unavailable. Please try again later or contact support if the issue persists.");
  }
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: `User query for Memory Guard AI: "${query}"`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_CHATBOT,
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
      }
    });

    const text = response.text;
    if (text && text.trim().length > 0) {
      return text;
    } else {
      console.warn("Gemini API returned an empty or invalid response for chatbot query:", query);
      return "I received an unusual response from my knowledge base. Could you please try rephrasing your question or ask something else?";
    }
  } catch (error: any) {
    console.error('Memory Guard Gemini API error (chatbot):', error);
    if (error.message && (error.message.includes('API key not valid') || error.message.includes('API_KEY_INVALID'))) {
         throw new Error("The AI assistant is temporarily unavailable due to a configuration issue. Please try again later.");
    }
    throw new Error('Sorry, I encountered an issue while processing your request for the AI assistant. Please try again in a few moments.');
  }
};

const VOICE_ANALYSIS_PROMPT_TEMPLATE = (audioMimeType: string) => `
You are an AI assistant performing a general analysis of speech patterns from an audio recording.
The user has provided an audio sample (MIME type: ${audioMimeType}).
Carefully analyze this audio. Based *only* on the provided audio, describe the general speech characteristics observed.

Consider the following aspects in your analysis:
- **Fluency and Flow:** Is the speech generally smooth, or are there frequent hesitations, repetitions, or self-corrections?
- **Pace:** Is the speech rate perceived as slow, moderate, or fast? Is the pace consistent or varied?
- **Clarity and Articulation:** How clear is the articulation of words and sounds?
- **Tone and Intonation:** Is the tone monotonous, or does it have a natural range of intonation and expressiveness?
- **Word Choice and Vocabulary (if discernible and noteworthy):** Are there any observable patterns in word usage or an unusually limited or rich vocabulary, if this can be determined purely from listening?
- **Sentence Structure (if discernible and noteworthy):** Are sentences typically simple or complex? Are there noticeable patterns in how sentences are formed?
- **Presence of Filler Words/Pauses:** Note any significant use of filler words (e.g., "um," "uh") or unusually long or frequent pauses.

**IMPORTANT INSTRUCTIONS:**
1.  **DO NOT PROVIDE MEDICAL ADVICE OR DIAGNOSIS.** Under no circumstances should you mention or imply any medical conditions, including but not limited to Alzheimer's disease, dementia, cognitive decline, or any other health issues.
2.  **DO NOT INTERPRET THE FINDINGS IN A MEDICAL CONTEXT.** Your role is strictly to describe observable speech patterns.
3.  **Focus on objective observations** from the audio itself. Avoid speculation.
4.  Present your analysis in a clear, neutral, and easy-to-understand summary. Use bullet points for different aspects if helpful.
5.  **ALWAYS CONCLUDE your entire response with the following exact disclaimer, without any modifications:** "This analysis is based on general speech patterns observed in the audio sample and is for informational purposes only. It is not a medical diagnosis or assessment. For any health concerns or questions about cognitive health, please consult a qualified healthcare professional."

Provide only the analysis and the mandatory disclaimer.
`;

export const analyzeAudioForCognitivePatterns = async (audioBase64: string, audioMimeType: string): Promise<string> => {
  if (!apiKey || apiKey === "MISSING_API_KEY") {
    console.error("Memory Guard Voice Analysis: API key is not configured.");
    throw new Error("The voice analysis feature is currently unavailable. Please check API key configuration.");
  }
  try {
    const audioPart = {
      inlineData: {
        data: audioBase64,
        mimeType: audioMimeType,
      },
    };
    const textPart = {
      text: VOICE_ANALYSIS_PROMPT_TEMPLATE(audioMimeType),
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME, // This model supports multimodal input
      contents: { parts: [textPart, audioPart] }, // Order might matter, text prompt first for context
      // Config options can be added if needed, e.g., temperature for voice analysis response.
      // System instruction is not used here as the prompt itself is highly specific.
    });
    
    const text = response.text;
    if (text && text.trim().length > 0) {
      // Ensure the disclaimer is present, though the prompt strongly dictates it.
      if (!text.includes("please consult a qualified healthcare professional.")) {
         // If by some chance the AI missed the explicit disclaimer, append it.
         // This is a safety net.
         return text + "\n\nThis analysis is based on general speech patterns observed in the audio sample and is for informational purposes only. It is not a medical diagnosis or assessment. For any health concerns or questions about cognitive health, please consult a qualified healthcare professional.";
      }
      return text;
    } else {
      console.warn("Gemini API returned an empty or invalid response for voice analysis.");
      return "The AI could not process the audio sample as expected. Please try again with a clear audio recording. If the issue persists, the sample might be too short, too long, or in an unsupported format for detailed analysis.";
    }
  } catch (error: any) {
    console.error('Memory Guard Gemini API error (voice analysis):', error);
     if (error.message && (error.message.includes('API key not valid') || error.message.includes('API_KEY_INVALID'))) {
         throw new Error("The voice analysis service is temporarily unavailable due to a configuration issue.");
    } else if (error.message && error.message.includes("candidate.finishReason")) { // More specific error for content filtering etc.
        throw new Error("The audio sample could not be processed due to content restrictions or an unexpected issue. Please ensure the audio is clear and appropriate. If the problem continues, try a different sample.");
    }
    throw new Error('Sorry, an unexpected error occurred while analyzing your voice sample. Please try again.');
  }
};
