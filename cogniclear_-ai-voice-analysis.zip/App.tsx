
import React from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import FeaturesSection from './components/FeaturesSection';
import HowItWorksSection from './components/HowItWorksSection';
import AiAssistantSection from './components/AiAssistantSection';
import CallToActionSection from './components/CallToActionSection';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <HeroSection />
        <FeaturesSection />
        <HowItWorksSection />
        <AiAssistantSection />
        <CallToActionSection />
      </main>
      <Footer />
    </div>
  );
};

export default App;
