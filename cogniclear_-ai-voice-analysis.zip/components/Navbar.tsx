
import React from 'react';
import { BrainCircuitIcon } from './icons/BrainCircuitIcon';

const Navbar: React.FC = () => {
  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <BrainCircuitIcon className="h-8 w-8 text-brandPurple-DEFAULT" />
            <span className="ml-2 text-2xl font-bold text-brandPurple-dark">CogniClear</span>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <a href="#home" className="text-gray-600 hover:text-brandPurple-DEFAULT px-3 py-2 rounded-md text-sm font-medium">Home</a>
              <a href="#features" className="text-gray-600 hover:text-brandPurple-DEFAULT px-3 py-2 rounded-md text-sm font-medium">Features</a>
              <a href="#howitworks" className="text-gray-600 hover:text-brandPurple-DEFAULT px-3 py-2 rounded-md text-sm font-medium">How It Works</a>
              <a href="#ai-assistant" className="text-gray-600 hover:text-brandPurple-DEFAULT px-3 py-2 rounded-md text-sm font-medium">AI Assistant</a>
              <a href="#cta" className="text-gray-600 hover:text-brandPurple-DEFAULT px-3 py-2 rounded-md text-sm font-medium">Get Started</a>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
