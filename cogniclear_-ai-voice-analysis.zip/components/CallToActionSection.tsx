
import React from 'react';

const CallToActionSection: React.FC = () => {
  return (
    <section id="cta" className="bg-gradient-to-r from-brandTeal-DEFAULT to-brandPurple-DEFAULT py-16 sm:py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
          Ready to Take the Next Step in Understanding Cognitive Health?
        </h2>
        <p className="mt-4 text-lg text-purple-100 max-w-2xl mx-auto">
          While CogniClear is in development, you can learn more about cognitive wellness and the science behind voice analysis. Join our mailing list for updates on our launch.
        </p>
        <div className="mt-10">
          <a
            href="mailto:info@cogniclear.example.com?subject=Interest%20in%20CogniClear"
            className="inline-block bg-white text-brandPurple-dark font-semibold px-8 py-4 rounded-lg shadow-lg hover:bg-gray-100 transition duration-300 text-lg mr-4 mb-4 sm:mb-0"
          >
            Request Updates
          </a>
          <a
            href="#howitworks"
            className="inline-block bg-transparent border-2 border-white text-white font-semibold px-8 py-4 rounded-lg hover:bg-white hover:text-brandTeal-dark transition duration-300 text-lg"
          >
            Learn More
          </a>
        </div>
      </div>
    </section>
  );
};

export default CallToActionSection;
