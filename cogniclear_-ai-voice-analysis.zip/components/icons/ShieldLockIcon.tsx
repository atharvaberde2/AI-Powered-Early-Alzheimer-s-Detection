
import React from 'react';

export const ShieldLockIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622A11.99 11.99 0 0014.402 6a11.959 11.959 0 01-1.536-2.286A11.977 11.977 0 0012 2.75c-.71 0-1.401.096-2.064.286zM9 12.75a3 3 0 016 0v1.5a3 3 0 01-6 0v-1.5z" />
  </svg>
);
