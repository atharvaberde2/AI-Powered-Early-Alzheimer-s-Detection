
import React from 'react';

export const AiChipIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-15 3.75H3m18 0h-1.5M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5.25 1.5H12v-3h3.75v3zm-3.75-3H9v3h3V9z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15V9.75M12 12h.008v.008H12V12zm0 0h.008v.008H12V12zm-.008 0H12v.008h-.008V12zm0 0H12v.008h-.008V12zM9 12.75h6" />
 </svg>
);
