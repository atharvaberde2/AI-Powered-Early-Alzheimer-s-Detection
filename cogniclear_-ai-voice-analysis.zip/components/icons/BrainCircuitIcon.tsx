
import React from 'react';

export const BrainCircuitIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5a6.375 6.375 0 00-6.375 6.375c0 2.454.71 4.708 2.016 6.55N12 21.75l4.359-4.325A8.91 8.91 0 0018.375 10.875 6.375 6.375 0 0012 4.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 12.75h.008v.008H12v-.008zm0-2.25h.008v.008H12v-.008zM7.5 12h.008v.008H7.5V12zm4.5 4.5h.008v.008H12v-.008zm2.25-2.25h.008v.008H14.25v-.008zm2.25-2.25h.008v.008H16.5v-.008zM12 2.25V4.5m0 15V21.75m-4.5-9.75H4.5m15 0H19.5m-15 4.5H4.5m15 0H19.5" />
  </svg>
);
