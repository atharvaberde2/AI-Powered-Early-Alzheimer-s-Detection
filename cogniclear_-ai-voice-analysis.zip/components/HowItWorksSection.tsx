
import React from 'react';
import { ChatBubbleLeftRightIcon } from './icons/ChatBubbleLeftRightIcon';
import { CogIcon } from './icons/CogIcon';
import { DocumentChartBarIcon } from './icons/DocumentChartBarIcon';

interface Step {
  id: number;
  Icon: React.FC<React.SVGProps<SVGSVGElement>>;
  title: string;
  description: string;
}

const steps: Step[] = [
  {
    id: 1,
    Icon: ChatBubbleLeftRightIcon,
    title: 'Speak Naturally',
    description: 'Record a short voice sample by responding to simple prompts or describing an image. The process is quick and easy.',
  },
  {
    id: 2,
    Icon: CogIcon,
    title: 'AI Analysis',
    description: 'Our advanced AI algorithms process your voice data, analyzing numerous acoustic and linguistic features for patterns.',
  },
  {
    id: 3,
    Icon: DocumentChartBarIcon,
    title: 'Understandable Insights',
    description: 'Receive a report summarizing the findings in an easy-to-understand format. Note: This is not a diagnosis.',
  },
];

const HowItWorksSection: React.FC = () => {
  return (
    <section id="howitworks" className="py-16 sm:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-brandPurple-dark">Simple Steps to Insights</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Our process is designed to be user-friendly and provide valuable information regarding cognitive patterns.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {steps.map((step, index) => (
            <div key={step.id} className="flex flex-col items-center text-center p-6">
              <div className="relative flex items-center justify-center">
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 left-full w-20 border-t-2 border-dashed border-brandTeal-DEFAULT -translate-y-1/2 ml-4"></div>
                )}
                <div className="bg-brandTeal-DEFAULT text-white p-5 rounded-full shadow-md">
                  <step.Icon className="w-10 h-10" />
                </div>
              </div>
              <h3 className="mt-6 text-xl font-semibold text-gray-800">{step.title}</h3>
              <p className="mt-2 text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
         <p className="mt-12 text-center text-sm text-gray-500">
            <strong>Important:</strong> CogniClear provides insights based on voice patterns and is not a diagnostic tool. Results should be discussed with a qualified healthcare professional.
          </p>
      </div>
    </section>
  );
};

export default HowItWorksSection;
