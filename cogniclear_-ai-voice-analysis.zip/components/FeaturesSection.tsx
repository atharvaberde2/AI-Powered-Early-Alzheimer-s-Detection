
import React from 'react';
import { MicrophoneIcon } from './icons/MicrophoneIcon';
import { AiChipIcon } from './icons/AiChipIcon';
import { MagnifyingGlassIcon } from './icons/MagnifyingGlassIcon';
import { ShieldLockIcon } from './icons/ShieldLockIcon';
import { Feature } from '../types';


const features: Feature[] = [
  {
    Icon: MicrophoneIcon,
    title: 'Voice-Powered Analysis',
    description: 'Utilizes sophisticated voice recognition to capture linguistic and acoustic features from your speech.',
    bgColor: 'bg-purple-100',
    iconColor: 'text-brandPurple-DEFAULT',
  },
  {
    Icon: AiChipIcon,
    title: 'AI-Driven Insights',
    description: 'Our AI algorithms analyze speech patterns, identifying subtle markers potentially linked to cognitive changes.',
    bgColor: 'bg-teal-50',
    iconColor: 'text-brandTeal-DEFAULT',
  },
  {
    Icon: MagnifyingGlassIcon,
    title: 'Focus on Early Detection',
    description: 'Designed to help identify early indicators, enabling timely consultation and proactive cognitive care planning.',
    bgColor: 'bg-purple-100',
    iconColor: 'text-brandPurple-DEFAULT',
  },
  {
    Icon: ShieldLockIcon,
    title: 'Secure & Private',
    description: 'We prioritize your privacy. All data is handled securely and confidentially, adhering to strict privacy standards.',
    bgColor: 'bg-teal-50',
    iconColor: 'text-brandTeal-DEFAULT',
  },
];

const FeatureCard: React.FC<{ feature: Feature }> = ({ feature }) => {
  const { Icon, title, description, bgColor, iconColor } = feature;
  return (
    <div className={`p-6 rounded-xl shadow-lg flex flex-col items-center text-center ${bgColor}`}>
      <div className={`p-4 rounded-full ${iconColor} bg-white mb-4 inline-block`}>
        <Icon className="w-10 h-10" />
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>
      <p className="text-gray-600 text-sm leading-relaxed">{description}</p>
    </div>
  );
};

const FeaturesSection: React.FC = () => {
  return (
    <section id="features" className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-brandPurple-dark">Empowering Cognitive Wellness</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Discover the innovative features that make CogniClear a unique tool for understanding cognitive patterns.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature) => (
            <FeatureCard key={feature.title} feature={feature} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
