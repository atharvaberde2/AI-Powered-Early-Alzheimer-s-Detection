
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center">
        <p className="text-sm text-gray-400">
          &copy; {new Date().getFullYear()} CogniClear. All rights reserved.
        </p>
        <p className="text-xs text-gray-500 mt-2">
          CogniClear is an informational tool and does not provide medical advice, diagnosis, or treatment. Always consult with a qualified healthcare professional for any health concerns or before making any decisions related to your health or treatment.
        </p>
        <div className="mt-4 space-x-4">
            <a href="#" className="text-xs text-gray-400 hover:text-brandTeal-light">Privacy Policy</a>
            <span className="text-gray-500">|</span>
            <a href="#" className="text-xs text-gray-400 hover:text-brandTeal-light">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
