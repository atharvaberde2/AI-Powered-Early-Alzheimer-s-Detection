
import React, { useState, useCallback } from 'react';
import { getInformativeAnswer } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';
import { PaperAirplaneIcon } from './icons/PaperAirplaneIcon';

const AiAssistantSection: React.FC = () => {
  const [query, setQuery] = useState<string>('');
  const [response, setResponse] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) {
      setError('Please enter a question.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResponse('');

    try {
      const answer = await getInformativeAnswer(query);
      setResponse(answer);
    } catch (err: any) {
      setError(err.message || 'Failed to get a response from the AI assistant. Please try again.');
      console.error("AI Assistant Error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [query]);

  return (
    <section id="ai-assistant" className="py-16 sm:py-24 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <SparklesIcon className="w-12 h-12 text-brandPurple-DEFAULT mx-auto mb-4" />
          <h2 className="text-3xl sm:text-4xl font-extrabold text-brandPurple-dark">Ask Our AI Assistant</h2>
          <p className="mt-4 text-lg text-gray-600">
            Have questions about cognitive health, Alzheimer's, or how AI can help? Get general information from our AI assistant.
          </p>
           <p className="mt-2 text-sm text-gray-500">
            (Powered by Google Gemini. This tool provides general information and is not a substitute for professional medical advice.)
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="ai-query" className="block text-sm font-medium text-gray-700 sr-only">
              Your question
            </label>
            <div className="mt-1 flex rounded-md shadow-sm">
                <input
                type="text"
                name="ai-query"
                id="ai-query"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="focus:ring-brandPurple-DEFAULT focus:border-brandPurple-DEFAULT flex-1 block w-full rounded-none rounded-l-md sm:text-sm border-gray-300 p-3"
                placeholder="E.g., What are common early signs of cognitive decline?"
                />
                <button
                type="submit"
                disabled={isLoading}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-r-md shadow-sm text-white bg-brandPurple-DEFAULT hover:bg-brandPurple-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brandPurple-light disabled:opacity-50"
                >
                {isLoading ? (
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                ) : (
                   <PaperAirplaneIcon className="h-5 w-5" />
                )}
                <span className="ml-2">{isLoading ? 'Asking...' : 'Ask'}</span>
                </button>
            </div>
          </div>
        </form>

        {error && (
          <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md">
            <p>{error}</p>
          </div>
        )}

        {response && (
          <div className="mt-6 p-6 bg-teal-50 rounded-lg shadow">
            <h4 className="text-md font-semibold text-brandTeal-dark mb-2">AI Assistant's Response:</h4>
            <p className="text-gray-700 whitespace-pre-wrap">{response}</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default AiAssistantSection;
