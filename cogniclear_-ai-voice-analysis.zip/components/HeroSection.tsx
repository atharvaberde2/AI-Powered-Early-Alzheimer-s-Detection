
import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <section id="home" className="bg-gradient-to-br from-brandPurple-light via-brandPurple-DEFAULT to-brandTeal-light py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight">
          <span className="block">Early Insights into Cognitive Health</span>
          <span className="block text-brandTeal-light mt-2">Through Your Voice</span>
        </h1>
        <p className="mt-6 max-w-2xl mx-auto text-lg md:text-xl text-purple-100">
          CogniClear leverages advanced AI and voice analysis to detect subtle patterns that may indicate early cognitive changes. Empower yourself with knowledge and take proactive steps towards brain wellness.
        </p>
        <div className="mt-10">
          <a
            href="#features"
            className="inline-block bg-white text-brandPurple-dark font-semibold px-8 py-3 rounded-lg shadow-lg hover:bg-gray-100 transition duration-300 text-lg"
          >
            Discover How It Works
          </a>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
