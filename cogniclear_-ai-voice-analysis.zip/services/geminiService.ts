
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_MODEL_NAME } from '../constants';

// Ensure process.env.API_KEY is handled by the build/runtime environment
const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "MISSING_API_KEY" }); // Fallback to prevent crash if key is missing

const SYSTEM_INSTRUCTION = `You are a helpful AI assistant specialized in providing general information about cognitive health, Alzheimer's disease, and related topics. 
Your responses should be:
1. Informative and easy to understand for a general audience.
2. Empathetic and supportive in tone.
3. Strictly general information. You MUST NOT provide medical advice, diagnosis, or treatment recommendations.
4. Always conclude by advising the user to consult with a qualified healthcare professional for any personal health concerns or medical advice.
5. Keep answers concise, ideally under 150 words.`;

export const getInformativeAnswer = async (query: string): Promise<string> => {
  if (!apiKey) {
    throw new Error("API key is not configured. Cannot contact AI assistant.");
  }
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: query,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
      }
    });

    const text = response.text;
    if (text) {
      return text;
    } else {
      // This case should ideally be handled by the Gemini SDK returning an error or more specific response structure.
      // For robustness, we check if text is empty.
      return "I received an empty response. Please try rephrasing your question or try again later.";
    }
  } catch (error: any) {
    console.error('Gemini API error:', error);
    if (error.message && error.message.includes('API key not valid')) {
         throw new Error("The AI assistant is currently unavailable due to an API key issue. Please try again later.");
    }
    throw new Error('Sorry, I encountered an issue while trying to get an answer. Please try again later.');
  }
};
